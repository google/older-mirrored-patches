/* Modified from v0.33 on Feb 17, 2005 by Google */
#ifndef TITLE_H
#define TITLE_H

#include <stdio.h>
#include <string.h>

#ifndef WIN32
#include <strings.h>
#endif

#define MAX_FONTSIZE 100
#define MAX_TITLELEN 128

class Title {
 public:

  Title() {
    knowntitle = NULL;
#ifdef WIN32 
    memset(fontstrings,0,MAX_FONTSIZE*sizeof(char *));
#else
    bzero(fontstrings, MAX_FONTSIZE*sizeof(char *));
#endif
    for(int i = 0; i < MAX_FONTSIZE; i++)
      dontadd[i] = false;
  }

  void SetTitle(char *title) {
    knowntitle = new char[MAX_TITLELEN];
    strncpy(knowntitle, title, 128);
    knowntitle[MAX_TITLELEN-1] = 0;
  }

  void ConsiderTitle(char *title) {
    if (strchr(title, ' ') && 
        strcmp(title, "Corel Office Document")&& 
        strcmp(title, "Untitled Document") && 
        strncmp(title, "Microsoft Word - ", strlen("Microsoft Word - ")) &&
        !strstr(title, ".pdf") && !strstr(title, ".PDF")) {
      SetTitle(title);
    }
  }

  void AddString(char *str, int fontsize) {
    if (knowntitle) return;
    if (fontsize >= MAX_FONTSIZE || fontsize < 0 || dontadd[fontsize]) return;
    if (fontstrings[fontsize] == NULL) {
      fontstrings[fontsize] = new char[MAX_TITLELEN];
      strncpy(fontstrings[fontsize], str, MAX_TITLELEN);
      fontstrings[fontsize][MAX_TITLELEN-1] = 0;
    } else {
      int len1 = strlen(fontstrings[fontsize]);
      int len2 = strlen(str);
      if (len1 + len2 < MAX_TITLELEN) {
        strncpy(fontstrings[fontsize]+len1, " ", 2);
        strncpy(fontstrings[fontsize]+len1+1, str, MAX_TITLELEN-len1-2);
        fontstrings[fontsize][MAX_TITLELEN-1] = 0;
      } else {
        dontadd[fontsize] = true;
      }
    } 
  }

  void EndFont(int fontsize) {
    dontadd[fontsize] = true;
  }

  bool HasTitle() {return(knowntitle != NULL);}

  const char *GetTitle() {
    if (knowntitle) return knowntitle;
    for(int i = MAX_FONTSIZE-1; i > 0; i--) {
      if (fontstrings[i] && !isNumber(fontstrings[i]) && 
          strlen(fontstrings[i]) > 5)
        return fontstrings[i];
    }
    return "Untitled";
  }

 private:
  char *fontstrings[MAX_FONTSIZE];
  bool dontadd[MAX_FONTSIZE];
  char *knowntitle;
  
  bool isNumber(char *str) {
    for(char *c = str; *c; c++)
      if(!strchr("0123456789.-+=_,\\/[]() ", *c)) 
        return false;
    return true;
  }
};

#endif /* TITLE_H */
