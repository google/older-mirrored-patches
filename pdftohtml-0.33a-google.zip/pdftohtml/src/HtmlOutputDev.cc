/* Modified from v0.33 on Feb 17, 2005 by Google */
//========================================================================
//
// HtmlOutputDev.cc
//
// Copyright 1997 Derek B. Noonburg
//
// Changed 1999-2000 by G.Ovtcharov
//========================================================================

#ifdef __GNUC__
#pragma implementation
#endif

#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <stddef.h>
#include <ctype.h>
#include <math.h>
#include "GString.h"
#include "GList.h"
#include "gmem.h"
#include "config.h"
#include "Error.h"
#include "GfxState.h"
#include "GlobalParams.h"
#include "HtmlOutputDev.h"
#include "HtmlFonts.h"
#include "Title.h"


int HtmlPage::pgNum=0;
int HtmlOutputDev::imgNum=1;

extern double scale;
extern GBool mode;
extern char extension[5];
extern GBool ignore;
extern GBool printCommands;
extern GBool printHtml;
extern GBool noframes;
extern GBool stout;
extern GBool xml;
extern GBool googlemode;
extern GBool noArchive;

// Minimum word separation, a fraction of font size.
static const double kMinWordSep = 0.2;

//------------------------------------------------------------------------
// HtmlString
//------------------------------------------------------------------------

GString* basename(GString* str){
  
  char *p=str->getCString();
  int len=str->getLength();
  for (int i=len-1;i>=0;i--)
    if (*(p+i)==SLASH) 
      return new GString((p+i+1),len-i-1);
  return new GString(str);
}

GString* Dirname(GString* str){
  
  char *p=str->getCString();
  int len=str->getLength();
  for (int i=len-1;i>=0;i--)
    if (*(p+i)==SLASH) 
      return new GString(p,i+1);
  return new GString();
} 

HtmlString::HtmlString(GfxState *state, double fontSize, HtmlFontAccu* fonts) {
  double x, y;
  state->transform(state->getCurX(), state->getCurY(), &x, &y);
  GfxFont* const font = state->getFont();
  if (font != NULL) {
    yMin = y - font->getAscent() * fontSize;
    yMax = y - font->getDescent() * fontSize;
  } else {
    // this means that the PDF file draws text without a current font,
    // which should never happen but it does
    yMin = y - 0.95 * fontSize;
    yMax = y + 0.35 * fontSize;
  }
  GfxRGB rgb;
  const int render = state->getRender();
  if ((render & 1) == 0) {  // see render mode constants in pdf spec
    // use fill color for modes that fill: 0, 2, 4, 6
    state->getFillRGB(&rgb);
  } else if ((render & 2) == 0) {
    // use stroke color for modes that stroke but don't fill: 1, 5
    state->getStrokeRGB(&rgb);
  } else {
    // use black for invisible mode (3), and clip-only mode (7)
    rgb.r = rgb.g = rgb.b = 0;
  }
  HtmlFont hfont =
    HtmlFont(state->getFont(), static_cast<int>(fontSize - 2), rgb);
  fontpos=fonts->AddFont(hfont);
  text = NULL;
  len = size = 0;
  yxNext = NULL;
  xyNext = NULL;
  htext = NULL;
  mergeNext = gFalse;
  escape = gTrue;
}


HtmlString::~HtmlString() {
  gfree(text);
  delete htext;
}

void HtmlString::addChars(GfxState *state, double x, double y,
			  double dx, double dy, Unicode *u, int uLen) {
  if (len + uLen > size) {
    size += 16 + len + uLen - size;
    text = (Unicode *)grealloc(text, size * sizeof(Unicode));
  }
  memcpy(&text[len], u, uLen * sizeof(Unicode));
  if (len == 0) {
    xMin = x;
  }
  xMax = x + dx;
  len += uLen;
}



//------------------------------------------------------------------------
// HtmlPage
//------------------------------------------------------------------------

HtmlPage::HtmlPage(GBool rawOrder, GBool printHR) {
  this->rawOrder = rawOrder;
  this->printHR = printHR;
  curStr = NULL;
  yxStrings = NULL;
  xyStrings = NULL;
  yxCur1 = yxCur2 = NULL;
  fonts=new HtmlFontAccu();
  links=new HtmlLinks();
  pageWidth=0;
  pageHeight=0;
  DocName=NULL;
}

HtmlPage::~HtmlPage() {
  clear();
  if (DocName) delete DocName;
  if (fonts) delete fonts;
  if (links) delete links;
  
}

void HtmlPage::updateFont(GfxState *state) {
  GfxFont *font;
  double *fm;
  char *name;
  int code;

  // adjust the font size
  fontSize = state->getTransformedFontSize();
  if ((font = state->getFont()) && font->getType() == fontType3) {
    // This is a hack which makes it possible to deal with some Type 3
    // fonts.  The problem is that it's impossible to know what the
    // base coordinate system used in the font is without actually
    // rendering the font.  This code tries to guess by looking at the
    // width of the character 'm' (which breaks if the font is a
    // subset that doesn't contain 'm').
    for (code = 0; code < 256; ++code) {
      if ((name = ((Gfx8BitFont *)font)->getCharName(code)) &&
	  name[0] == 'm' && name[1] == '\0') {
	break;
      }
    }
    if (code < 256) {
      // 600 is a generic average 'm' width -- yes, this is a hack
      fontSize *= ((Gfx8BitFont *)font)->getWidth(code) / 0.6;
    }
    fm = font->getFontMatrix();
    if (fm[0] != 0) {
      fontSize *= fabs(fm[3] / fm[0]);
    }
  }
  if (fontSize <= 0) {
    fontSize = 10;  // default font size when unknown
  } else if (fontSize < 6) {
    fontSize = 6;  // minimum font size
  }
}

void HtmlPage::beginString(GfxState *state, GString *s) {
  curStr = new HtmlString(state, fontSize, fonts);
  if(!pageWidth) {
      pageWidth=static_cast<int>(state->getPageWidth());
      pageHeight=static_cast<int>(state->getPageHeight());
  }
}


// Convert tmp->text to tmp->htext -- encode and escape Unicode.
void HtmlPage::conv() {
  HtmlString *tmp;

  int k=0;
  HtmlFont h;
  for(tmp=yxStrings; tmp; tmp=tmp->yxNext){
    int pos=tmp->fontpos;
    //  printf("%d\n",pos);
    h=fonts->Get(pos);

    if (tmp->htext) delete tmp->htext; 
     
    if (links->inLink(tmp->xMin,tmp->yMin,tmp->xMax,tmp->yMax,k)){
      GString linktext, *final, *temp;
      int startpos, endpos;
      HtmlLink *link = links->getLink(k);
      link->getStart(tmp->xMin, tmp->xMax, tmp->len, &linktext, &startpos);
      tmp->htext = HtmlFont::simple(h, tmp->text, startpos);
      tmp->htext->append(&linktext);
      link->getEnd(tmp->xMin, tmp->xMax, tmp->len, &linktext, &endpos);
      temp = HtmlFont::simple(h, tmp->text+startpos, endpos-startpos);
      tmp->htext->append(temp);
      delete temp;
      tmp->htext->append(&linktext);
      temp = HtmlFont::simple(h, tmp->text+endpos, tmp->len-endpos);
      tmp->htext->append(temp);
      delete temp;
    } else if (tmp->escape) {
      tmp->htext=HtmlFont::simple(h,tmp->text,tmp->len);
    } else {
      tmp->htext = new GString;
      for (int i = 0; i < tmp->len; i++) {
        tmp->htext->append(tmp->text[i]);
      }
    }
  }

}


void HtmlPage::addChar(GfxState *state, double x, double y,
		       double dx, double dy, Unicode *u, int uLen) {

  // Convert (x, y) to device space.
  double x1, y1;
  state->transform(x, y, &x1, &y1);

  // Start a new string if the horizontal gap is large, i.e., bigger than
  // a fixed fraction of the font size.  This heuristic can generate bad
  // splits in some cases but we deal with that in coalesce().  Also break
  // before and after the diacritical marks, to simplify Unicode hacks in
  // coalesce().
  if (curStr->len > 0 &&
      (fabs(x1 - curStr->xMax) > kMinWordSep * fontSize ||
       HtmlFont::diacriticalIndex(curStr->text[curStr->len - 1]) > 0 ||
       (uLen > 0 && HtmlFont::diacriticalIndex(*u) > 0))) {
    endString();
    beginString(state, NULL);
  }

  // The position of the first character in the string is rather important.
  // Make sure it's not a space, because spaces are often misplaced and
  // their dimensions may be out of whack.
  if (curStr->len == 0 && uLen == 1 && *u == 0x20) {
    return;
  }

  // Exclude extra spacing from character dimensions.  There are two kinds
  // of text spacing in pdf -- normal inter-character spacing and extra
  // inter-word spacing.
  double dx2, dy2;
  double sp = state->getCharSpace();
  if (uLen == 1 && *u == 0x20) {  // also apply inter-word spacing
    sp += state->getWordSpace();
  }
  state->textTransformDelta(sp * state->getHorizScaling(), 0, &dx2, &dy2);
  dx -= dx2;
  dy -= dy2;

  // Convert (dx, dy) to device space.
  double w1, h1;
  state->transformDelta(dx, dy, &w1, &h1);

  // Accumulate current string.
  curStr->addChars(state, x1, y1, w1, h1, u, uLen);
}

void HtmlPage::addPath(GfxState *state) {
  // Draw long and narrow horizontal lines with <hr> --
  // they are useful as separators for parsing scientific papers.
  // Do not draw short lines because there are lots of them and misalignment
  // is visually confusing.  Do not draw wide lines because they are probably
  // not horizontal lines to begin with.
  GfxPath* const path = state->getPath();
  if (path != NULL && path->getNumSubpaths() == 1) {
    GfxSubpath* const p = path->getSubpath(0);
    const int n = p->getNumPoints();
    if (n >= 2) {  // else it's not really a line
      double xmin, ymin;
      state->transform(p->getX(0), p->getY(0), &xmin, &ymin);
      double xmax = xmin, ymax = ymin;
      for (int i = 1; i < n; i++) {
        double x, y;
        state->transform(p->getX(i), p->getY(i), &x, &y);
        if (x < xmin) xmin = x; else if (x > xmax) xmax = x;
        if (y < ymin) ymin = y; else if (y > ymax) ymax = y;
      }
      maybeAddHR(state, xmin, ymin, xmax - xmin, ymax - ymin);
    }
  }
}

bool HtmlPage::maybeAddHR(
      GfxState* state, double x, double y, double dx, double dy) {
  if (!printHR) return false;  // this is turned on by a command line flag
  if (dx < 0) {
    x += dx;
    dx = -dx;
  }
  if (dy < 0) {
    y += dy;
    dy = -dy;
  }
  if (dx < 40 || dy > 2) {
    return false;  // not a long and thin horizontal line
  }

  // End the current string.
  if (curStr == NULL || curStr->len > 0) {
    endString();
    beginString(state, NULL);
  }

  // Add <hr>.
  char s[100];
  Unicode u[100];
#ifdef WIN32  
  _snprintf(s, sizeof(s), "<hr width=%d noshade size=1>", int(dx + 0.5));
#else
  snprintf(s, sizeof(s), "<hr width=%d noshade size=1>", int(dx + 0.5));
#endif
  const int len = strlen(s);
  for (int i = 0; i < len; i++) {
    u[i] = s[i];
  }
  curStr->addChars(state, x, y, dx, dy, u, len);
  curStr->yMin = y - 5;  // the defaults are based on font size and hence wrong
  curStr->yMax = y - 3;
  curStr->escape = false;
  endString();
#if 0 // debug
  fprintf(stderr, "HLINE: org=(%g, %g) dim=(%g, %g)\n", x, y, dx, dy);
#endif

  // Start new string.
  beginString(state, NULL);
  return true;
}

void HtmlPage::endString() {
  HtmlString *p1, *p2;
  double h, y1, y2;

  // nothing to end?
  if (curStr == NULL) {
    return;
  }

  // throw away zero-length strings -- they don't have valid xMin/xMax
  // values, and they're useless anyway
  if (curStr->len == 0) {
    delete curStr;
    curStr = NULL;
    return;
  }

#if 0 //~tmp
  if (curStr->yMax - curStr->yMin > 20) {
    delete curStr;
    curStr = NULL;
    return;
  }
#endif

  // insert string in y-major list
  h = curStr->yMax - curStr->yMin;
  y1 = curStr->yMin + 0.5 * h;
  y2 = curStr->yMin + 0.8 * h;
  if (rawOrder) {
    p1 = yxCur1;
    p2 = NULL;
  } else if ((!yxCur1 ||
              (y1 >= yxCur1->yMin &&
               (y2 >= yxCur1->yMax || curStr->xMax >= yxCur1->xMin))) &&
             (!yxCur2 ||
              (y1 < yxCur2->yMin ||
               (y2 < yxCur2->yMax && curStr->xMax < yxCur2->xMin)))) {
    p1 = yxCur1;
    p2 = yxCur2;
  } else {
    for (p1 = NULL, p2 = yxStrings; p2; p1 = p2, p2 = p2->yxNext) {
      if (y1 < p2->yMin || (y2 < p2->yMax && curStr->xMax < p2->xMin))
        break;
    }
    yxCur2 = p2;
  }
  yxCur1 = curStr;
  if (p1)
    p1->yxNext = curStr;
  else
    yxStrings = curStr;
  curStr->yxNext = p2;
  curStr = NULL;
}

inline GBool HtmlPage::dgte(double arg1, double arg2) {
  return (arg1 + .5 >= arg2);  //what's a pixel here or there?
}

inline GBool HtmlPage::deq(double arg1, double arg2) {
  double diff = arg1 - arg2;
  return (diff < 2.0 && diff > -2.0);  //what's a pixel here or there?
}

inline GBool HtmlPage::isEmpty(GString *str) {
  int len = str->getLength();
  for(int i = 0; i < len; i++) {
    switch(str->getChar(i)) {
      case ' ': break;
      default: return gFalse;
    }
  }
  return gTrue;
}

void HtmlPage::coalesce() {
  HtmlString *str1, *str2;
  HtmlFont hfont1, hfont2;
  GBool addSpace, sameFont;
  int i;

  if (yxStrings == NULL) return;

#if 0 //~ for debugging
  for (str1 = yxStrings; str1; str1 = str1->yxNext) {
    fprintf(stderr, "x=%3d..%3d  y=%3d..%3d  size=%2d '",
	   (int)str1->xMin, (int)str1->xMax, (int)str1->yMin, (int)str1->yMax,
	   (int)(str1->yMax - str1->yMin));
    for (i = 0; i < str1->len; ++i) {
      fputc(str1->text[i] & 0xff, stderr);
    }
    fprintf(stderr, "'\n");
  }
  fprintf(stderr, "\n------------------------------------------------------------\n\n");
#endif

  // Remove duplicate strings.
  str1 = yxStrings;
  while (str1 && (str2 = str1->yxNext)) {
    if (str1->len == str2->len && 
        deq(str1->xMin, str2->xMin) && 
        deq(str1->xMax, str2->xMax) && 
        deq(str1->yMin, str2->yMin) && 
        deq(str1->yMax, str2->yMax) && 
        getFont(str1).isEqual(getFont(str2)) &&
        !memcmp(str1->text, str2->text, sizeof(Unicode)*str1->len)) {
      str1->yxNext = str2->yxNext;
      delete str2;
    } else {
      str1 = str2;
    }
  }

  // Undo unicode display hacks.  Some pdf files draw the characters
  // and the accents separately.  We join them into accented characters.
  // E.g., u + dieresis becomes \"u.  It looks better on the screen
  // because otherwise the accents are often drawn far away from the
  // characters, due to spacing differences in fonts.  It also helps
  // parsing because the output is normalized.
  str1 = yxStrings;
  while (str1 != NULL && (str2 = str1->yxNext) != NULL) {
    Unicode u;
    // Note that addChar() always breaks words when it sees the accents,
    // so we can test for accented characters at the word boundaries only.
    // We don't store position information for individual characters so
    // we wouldn't know what to do with the accents inside the words anyway.
    // Also note that if two characters overlap and one of them is ASCII
    // and the other one is a diacritical mark, we take the ASCII one and
    // assume that the other character is a discardable decoration.
    if (fabs(str1->yMin - str2->yMin) <= 2.0 &&  // must be on the same line
        fabs(str1->xMax - str2->xMax) <= 5.0 &&  // right edges must be aligned
        getFont(str1).isEqual(getFont(str2)) &&  // must be same font
        str1->len > 0 && str2->len > 0 &&  // join last of str1 w/first of str2
        ((u = HtmlFont::join(str1->text[str1->len - 1], str2->text[0]))) != 0 ||
         (u = HtmlFont::join(str2->text[0], str1->text[str1->len - 1])) != 0 ||
         (isascii(u = str1->text[str1->len - 1]) &&
          HtmlFont::diacriticalIndex(str2->text[0]) > 0) ||
         (isascii(u = str2->text[0]) &&
          HtmlFont::diacriticalIndex(str1->text[str1->len - 1]) > 0)) {
      const int n = str1->len + str2->len - 1;
      if (str1->size < n) {
        str1->size = (n + 15) & ~15;
        str1->text =
          (Unicode*)grealloc(str1->text, str1->size * sizeof(Unicode));
      }
      str1->text[str1->len - 1] = u;  // joined character
      memcpy(&str1->text[str1->len], &str2->text[1],
             (str2->len - 1) * sizeof(Unicode));  // the rest of str2
      if (str2->xMax > str1->xMax) {
        str1->xMax = str2->xMax;
      }
      if (str2->yMax > str1->yMax) {
        str1->yMax = str2->yMax;
      }
      str1->yxNext = str2->yxNext;
      delete str2;
    } else {
      str1 = str2;
    }
  }

#if 0 //~ for debugging
  for (str1 = yxStrings; str1; str1 = str1->yxNext) {
    fprintf(stderr, "x=%3d..%3d  y=%3d..%3d  size=%2d '",
	   (int)str1->xMin, (int)str1->xMax, (int)str1->yMin, (int)str1->yMax,
	   (int)(str1->yMax - str1->yMin));
    for (i = 0; i < str1->len; ++i) {
      fputc(str1->text[i] & 0xff, stderr);
    }
    fprintf(stderr, "'\n");
  }
  fprintf(stderr, "\n------------------------------------------------------------\n\n");
#endif

  str1 = yxStrings;
  hfont1 = getFont(str1);
  while (str1 && (str2 = str1->yxNext)) {
    hfont2 = getFont(str2);
    const double d = str2->xMin - str1->xMax;

#if 0
    fprintf(stderr, "x=%g..%g  y=%g..%g  size=%2d d=%g space=%g %s'",
	   str1->xMin, str1->xMax, str1->yMin, str1->yMax,
            (int)(str1->yMax - str1->yMin), d, space, 
            (((rawOrder &&
	  ((dgte(str2->yMin, str1->yMin) && dgte(str1->yMax, str2->yMin)) ||
	   (dgte(str2->yMax, str1->yMin) && dgte(str1->yMax, str2->yMax)))) ||
              //((str2->yMin >= str1->yMin && str2->yMin <= str1->yMax) ||
              //(str2->yMax >= str1->yMin && str2->yMax <= str1->yMax))) ||
              (!rawOrder && str2->yMin < str1->yMax)) &&
             d > -0.5 * space && d < space) ? "YES" : "NO");
    for (i = 0; i < str1->len; ++i) {
      fputc(str1->text[i] & 0xff, stderr);
    }
    fprintf(stderr, "'\n");
#endif

    if (((rawOrder &&
          // str2 inside str1 (along the y axis) or the other way around
          ((str1->yMin <= str2->yMin + 2 && str2->yMax <= str1->yMax + 2) ||
           (str2->yMin <= str1->yMin + 2 && str1->yMax <= str2->yMax + 2))) ||
	 (!rawOrder && str2->yMin < str1->yMax)) &&
        -1.25 * hfont1.getSize() < d && d < 1.5 * hfont1.getSize() &&
	hfont1.getSize() == hfont2.getSize() &&
        str1->escape && str2->escape) {

      int n = str1->len;

      if ((sameFont = hfont1.isEqual(hfont2))) {
        n += str2->len;
      }

      if ((addSpace = d > kMinWordSep * hfont1.getSize())) {
	++n;
      }

      str1->size = (n + 15) & ~15;
      str1->text = (Unicode *)grealloc(str1->text,
				       str1->size * sizeof(Unicode));

      if (addSpace) {
	str1->text[str1->len] = 0x20;
	++str1->len;
      }
      if (sameFont) {
        for (i = 0; i < str2->len; ++i) {
          str1->text[str1->len] = str2->text[i];
          ++str1->len;
        }
        
        if (str2->xMax > str1->xMax) {
          str1->xMax = str2->xMax;
        }
        if (str2->yMax > str1->yMax) {
          str1->yMax = str2->yMax;
        }
        str1->yxNext = str2->yxNext;
        delete str2;
        continue;
      } else {

#if 0
        fprintf(stderr, "BLAH: %s, %s\n", 
                HtmlFont::simple(fonts->Get(str1->fontpos),str1->text,str1->len)->getCString(),
                HtmlFont::simple(fonts->Get(str2->fontpos),str2->text,str2->len)->getCString());
#endif

        str1->mergeNext = gTrue;
      }
    }
    str1 = str2;
    hfont1 = hfont2;
  }
}

void HtmlPage::dumpAsXML(FILE* f,int page){  
  fprintf(f, "<page number=\"%d\" position=\"absolute\"", page);
  fprintf(f," top=\"0\" left=\"0\" height=\"%d\" width=\"%d\">\n", pageHeight,pageWidth);
    
  for(int i=0;i!=fonts->size();i++) {
    GString *fontCSStyle = fonts->CSStyle(i);
    fprintf(f,"\t%s\n",fontCSStyle->getCString());
    delete fontCSStyle;
  }
  
  GString *str, *str1;
  for(HtmlString *tmp=yxStrings;tmp;tmp=tmp->yxNext){
    if (tmp->htext){
      str=new GString(tmp->htext);
      fprintf(f,"<text top=\"%d\" left=\"%d\" ",xoutRound(tmp->yMin),xoutRound(tmp->xMin));
      fprintf(f,"width=\"%d\" height=\"%d\" ",xoutRound(tmp->xMax-tmp->xMin),xoutRound(tmp->yMax-tmp->yMin));
      fprintf(f,"font=\"%d\">", tmp->fontpos);
      if (tmp->fontpos!=-1){
	str1=fonts->getCSStyle(tmp->fontpos,str);
      }
      fputs(str1->getCString(),f);
      delete str;
      delete str1;
      fputs("</text>\n",f);
    }
  }
  fputs("</page>\n",f);
}


void HtmlPage::dumpComplex(int page){
  FILE* f;

  GString* tmp=new GString(DocName);   
  GString* pgNum=GString::fromInt(page);
  tmp->append('-')->append(pgNum)->append(".html");
  delete pgNum;

  if (!(f = fopen(tmp->getCString(), "w"))) {
    error(-1, "Couldn't open html file '%s'", tmp->getCString());
    delete tmp;
    return;
  }    
  delete tmp;
  tmp=basename(DocName);
  
  fprintf(f,"<html>\n<head>\n<title>Page %d</title>\n\n",page);
  fprintf(f, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=%s\">\n", globalParams->getTextEncodingName()->getCString());
  fprintf(f, "%s\n", GENERATOR);
  fputs("<style type=\"text/css\">\n<!--\n",f);
    
  for(int i=0;i!=fonts->size();i++) {
    GString *fontCSStyle = fonts->CSStyle(i);
    fprintf(f,"\t%s\n",fontCSStyle->getCString());
    delete fontCSStyle;
  }
    
  fputs("-->\n</style>\n",f);
  fputs("</head>\n<body vlink=\"blue\" link=\"blue\">\n",f); 

  fputs("<div style=\"position:absolute;top:0;left:0\">",f);
  fprintf(f,"<img width=\"%d\" height=\"%d\" src=\"%s%03d.png\">",pageWidth,pageHeight,tmp->getCString(),page);
  fputs("</div>",f);
  
  delete tmp;
  
  GString *str, *str1;
  for(HtmlString *tmp1=yxStrings;tmp1;tmp1=tmp1->yxNext){
    if (tmp1->htext){
      str=new GString(tmp1->htext);
      fprintf(f,"<div style=\"position:absolute;top:%d;left:%d\">",xoutRound(tmp1->yMin),xoutRound(tmp1->xMin));
      fputs("<nobr>",f); 
      if (tmp1->fontpos!=-1){
	str1=fonts->getCSStyle(tmp1->fontpos,str);  
      }
      fputs(str1->getCString(),f);
      
      delete str;      
      delete str1;
      fputs("</nobr></div>\n",f);
    }
  }
  fputs("</body>\n</html>\n",f);
  fclose(f);
}

void HtmlPage::setFont(FILE *f, HtmlFont *font) {
  // note that some functions malloc new GString objects, which
  // should be deleted.
  GString *fontColor = font->getColor().toString();
  GString *fontName = font->getFontName();
  fprintf(f, "<font size=%d ", font->getSize()/10+2);
  if (fontColor->cmp("#000000"))
    fprintf(f, "color=\"%s\" ", fontColor->getCString());
  fprintf(f, "face=\"%s\">", fontName->getCString());
  fprintf(f, "<span style=\"font-size:%dpx;font-family:%s", font->getSize(),
          fontName->getCString());
  if (fontColor->cmp("#000000"))
    fprintf(f, ";color:%s", fontColor->getCString());
  fprintf(f, "\">\n");
  delete fontColor;
  delete fontName;
}

void HtmlPage::endFont(FILE *f) {
  fputs("</span></font>\n", f);
}

void HtmlPage::setSubFont(FILE *f, HtmlFont *oldfont, HtmlFont *font) {
  //fprintf(f, "<font size=%d ", font->getSize()/10+2);
  fprintf(f, "<font ");
  GString *fontColor    = font->getColor().toString();
  GString *oldFontColor = oldfont->getColor().toString();
  GString *fontName = font->getFontName();

  if (fontColor->cmp(oldFontColor))
    fprintf(f, "color=\"%s\" ", fontColor->getCString());
  fprintf(f, "face=\"%s\">", fontName->getCString());

  delete fontColor;
  delete oldFontColor;
  delete fontName;
  /* this messes up netscape 4.X
  fprintf(f, "<span style=\"font-size:%dpx;font-family:%s", font->getSize(),
          font->getFontName()->getCString());
  if (font->getColor().toString()->cmp("#000000"))
    fprintf(f, ";color:%s", font->getColor().toString()->getCString());
  fprintf(f, "\">");
  */
}

void HtmlPage::endSubFont(FILE *f) {
  fputs("</font>", f);
}

void HtmlPage::setPos(FILE *f, int yoffset, HtmlString *htmlstring) {
  // gcc has different floating point arithmetic depending upon
  // debug vs. optimized mode.
  // specifically, the xoutRound() call behaves differently for many numbers
  // ending in ".5".  since .5 is pretty common, we add .00001 to get something
  // not .5, and then we get consistent behavior, which makes for better
  // unittests.  this is an imperfect solution, but good enough for now.
  fprintf(f,"<div style=\"position:absolute;top:%d;left:%d\"><nobr>",
          xoutRound((htmlstring->yMin + .00001))+yoffset,xoutRound(htmlstring->xMin));
}

void HtmlPage::endPos(FILE *f) {
  fputs("</nobr></div>\n", f);
}

void HtmlPage::dumpGoogle(int nump, FILE *f, GString *docTitle) {
  static int yoffset=175;
  if (nump == 1) {
    Title document_title;
    int lastfontpos = -1;
    document_title.ConsiderTitle(docTitle->getCString());
    for(HtmlString *tmp=yxStrings;tmp;tmp=tmp->yxNext){
      if (tmp->htext && tmp->htext->getLength() > 0){
        if (lastfontpos >= 0 && (fonts->Get(tmp->fontpos).getSize() != 
                                 fonts->Get(lastfontpos).getSize()))
          document_title.EndFont(fonts->Get(lastfontpos).getSize());
        //tmp->htext->remove('\n');
        document_title.AddString(tmp->htext->getCString(), 
                                 fonts->Get(tmp->fontpos).getSize());
      }
    }
    
    fprintf(f, "<title>%s</title>\n</head>", document_title.GetTitle());
    
    fprintf(f, "<body  bgcolor=#ffffff vlink=\"blue\" link=\"blue\">\n");
    
    fprintf(f, "<table border=0 width=100%><tr>"
            "<td bgcolor=eeeeee align=right><font face=arial,sans-serif>"
            "<a name=%d><b>Page %d</b></a></font></td></tr></table>", 
            nump, nump);
  } else {
    fprintf(f,"\n<div style=\"position:absolute;top:%d;left:%d\"><hr>"
            "<table border=0 width=100%><tr><td bgcolor=eeeeee align=right>"
            "<font face=arial,sans-serif><a name=%d><b>Page %d</b></a>"
            "</font></td></tr></table></div>", yoffset, 0, nump, nump);
  }
  /*
    if (fonts->size()) {
    fputs("<style type=\"text/css\">\n<!--\n",f);
    for(int i=0;i!=fonts->size();i++)
    fprintf(f,"\t%s\n",fonts->CSStyle(i, nump)->getCString());
    fputs("-->\n</style>\n",f);
    }
  */


  HtmlFont *currFont = NULL, *newFont = NULL;
  GBool mergeNext = gFalse;
  GBool posSet    = gFalse;
  GBool bold      = gFalse;
  GBool italic    = gFalse;

  for(HtmlString *tmp=yxStrings; 
      tmp; 
      mergeNext = tmp->mergeNext, tmp = tmp->yxNext) {

    if (!tmp->mergeNext && isEmpty(tmp->htext))
      continue;

    newFont = fonts->GetP(tmp->fontpos);

    if (!mergeNext) {
      if (bold)
        fputs("</b>", f);

      if (italic)
        fputs("</i>", f);

      if (posSet)
        endPos(f);

      if (currFont != NULL && !(currFont->isEqualIgnoreBold(*newFont)))
        endFont(f);

      if (currFont == NULL || !(currFont->isEqualIgnoreBold(*newFont))) {
        currFont = newFont;
        setFont(f, currFont);
      }

      setPos(f, yoffset, tmp);
      posSet = gTrue;

      if (italic = newFont->isItalic())
        fputs("<i>", f);

      if (bold = newFont->isBold())
        fputs("<b>", f);
    }

    if (xoutRound(tmp->yMin) < 0 || !tmp->htext || 
        tmp->htext->getLength() <= 0)
      continue;

    if (bold && !newFont->isBold()) {
      bold = gFalse;
      fputs("</b>", f);
    }

    if (italic && !newFont->isItalic()) {
      italic = gFalse;
      fputs("</i>", f);
    }

    if (!italic && newFont->isItalic()) {
      italic = gTrue;
      fputs("<i>", f);
    }

    if (!bold && newFont->isBold()) {
      bold = gTrue;
      fputs("<b>", f);
    }

    if (!(currFont->isEqualIgnoreBold(*newFont))) {
      setSubFont(f, currFont, newFont);
      fputs(tmp->htext->getCString(), f);
      endSubFont(f);
    } else {
      fputs(tmp->htext->getCString(), f);
    }
    
  }
  if (bold)
    fputs("</b>", f);
  if (italic)
    fputs("</i>", f);
  if (posSet)
    endPos(f);
  if (currFont)
    endFont(f);
  yoffset += pageHeight;
#if 0  // debug
  fprintf(stderr, "END PAGE %d\n", yoffset);
#endif
}

void HtmlPage::dump(FILE *f, GString *docTitle) {
  static int nump=0;

  nump++;
  if (mode){
    if (xml) dumpAsXML(f,nump);
    if (!xml) dumpComplex(nump);  
  } 
  else if (googlemode) {
    dumpGoogle(nump, f, docTitle);
  } else {
    fprintf(f,"<a name=%d></a>",nump);
    GString* fName=basename(DocName); 
    for (int i=1;i<HtmlOutputDev::imgNum;i++)
      fprintf(f,"<img src=\"%s-%d_%d.jpg\"><br>\n",fName->getCString(),nump,i);
    HtmlOutputDev::imgNum=1;
    delete fName;

    GString* str;
    for(HtmlString *tmp=yxStrings;tmp;tmp=tmp->yxNext){
      if (tmp->htext){
	str=new GString(tmp->htext); 
	fputs(str->getCString(),f);
	delete str;      
	fputs("<br>\n",f);  
      }
    }   
  }
}



void HtmlPage::clear() {
  HtmlString *p1, *p2;

  if (curStr) {
    delete curStr;
    curStr = NULL;
  }
  for (p1 = yxStrings; p1; p1 = p2) {
    p2 = p1->yxNext;
    delete p1;
  }
  yxStrings = NULL;
  xyStrings = NULL;
  yxCur1 = yxCur2 = NULL;
  delete fonts;
  delete links;

  fonts=new HtmlFontAccu();
  links=new HtmlLinks();
 

}

void HtmlPage::setDocName(char *fname){
  DocName=new GString(fname);
}

//------------------------------------------------------------------------
// HtmlMetaVar: represent one meta tag
//------------------------------------------------------------------------

HtmlMetaVar::HtmlMetaVar(char *_name, char *_content) {
  name = new GString(_name);
  content = new GString(_content);
}

HtmlMetaVar::~HtmlMetaVar() {
  delete name;
  delete content;
} 
    
GString* HtmlMetaVar::toString() {
  GString *result = new GString("<meta name=\"");
  result->append(name);
  result->append("\" content=\"");
  result->append(content);
  result->append(xml ? "\"/>" : "\">");
  return result;
}

//------------------------------------------------------------------------
// HtmlOutputDev
//------------------------------------------------------------------------

void HtmlOutputDev::doFrame(){
  GString* fName=new GString(Docname);
  fName->append(".html");

  if (!(f = fopen(fName->getCString(), "w"))){
    delete fName;
    error(-1, "Couldn't open html file '%s'", fName->getCString());
    return;
  }
  
  delete fName;
    
  fName=basename(Docname);
  fputs("<html>",f);
  fputs("<head>",f);
  fprintf(f,"<title>%s</title>",docTitle->getCString());//fName->getCString());
  fprintf(f, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=%s\">\n", globalParams->getTextEncodingName()->getCString());
  fprintf(f, "%s\n", GENERATOR);
  dumpMetaVars(f);
  fprintf(f, "</head>\n");
  fputs("<frameset border=3 frameborder=\"yes\" framespacing=2 cols=\" 100,* \"\n>",f);
  fprintf(f,"<frame name=\"links\" src=\"%s_ind.html\" target=\"rechts\">\n",fName->getCString());
  fputs("<frame name=\"rechts\" src=",f); 
  if (mode) fprintf(f,"\"%s-1.html\"",fName->getCString());
    else
      fprintf(f,"\"%ss.html\"",fName->getCString());
  
  fputs(">\n</frameset>\n</html>\n",f);
 
  delete fName;
  fclose(f);  

}

HtmlOutputDev::HtmlOutputDev(char *fileName, GString *title, 
                             GList* glMetaVars,
                             GBool rawOrder,
                             GBool printHR) {
  this->glMetaVars = glMetaVars;
  f=NULL;
  docTitle = (title ? new GString(title) : new GString());
  dumpJPEG=gTrue;
  //write = gTrue;
  this->rawOrder = rawOrder;
  ok = gTrue;
  imgNum=1;
  pageNum=1;
  // open file
  needClose = gFalse;
  pages = new HtmlPage(rawOrder, printHR);

  maxPageWidth = 0;
  maxPageHeight = 0;

  pages->setDocName(fileName);
  Docname=new GString (fileName);

  /*GString *tmp=basename(Docname);
  if (tmp->getLength()==0) {
    printf("Error : illegal output file");
    exit(1);
    }*/

  //Complex and simple doc with frames
  if(!xml&&!noframes){
     GString* left=new GString(fileName);
     left->append("_ind.html");
     doFrame();
   
     if (!(f=fopen(left->getCString(), "w"))){
        error(-1, "Couldn't open html file '%s'", left->getCString());
	delete left;
        return;
     }
     delete left;
     fputs("<html>\n<head>\n<title></title>\n</head>\n<body>\n",f);
     
     if(!mode){
       GString* right=new GString(fileName);
       right->append("s.html");

       if (!(page=fopen(right->getCString(),"w"))){
        error(-1, "Couldn't open html file '%s'", right->getCString());
        delete right;
	return;
       }
       delete right;
       fputs("<html>\n<head>\n<title></title>\n</head>\n<body>\n",page);
     }
  }

  if (noframes) {
    if (stout) page=stdout;
    else {
      GString* right=new GString(fileName);
      if (!xml) right->append(".html");
      if (xml) right->append(".xml");
      if (!(page=fopen(right->getCString(),"w"))){
	delete right;
	error(-1, "Couldn't open html file '%s'", right->getCString());
	return;
      }  
      delete right;
    }
    if (xml) {
      fputs("<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n", page);
      fputs("<!DOCTYPE pdf2xml SYSTEM \"pdf2xml.dtd\">\n\n", page);
      fputs("<pdf2xml>\n",page);
      dumpMetaVars(page);
    } else if (googlemode) { 
      fprintf(page,"<html>\n<head>\n");
      fprintf(page, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=%s\">\n", globalParams->getTextEncodingName()->getCString());
      dumpMetaVars(page);
      if (noArchive) fprintf(page, "<meta NAME=\"ROBOTS\" CONTENT=\"NOARCHIVE\">\n");
    } else {
      fprintf(page,"<html>\n<head>\n<title>%s</title>\n",docTitle->getCString());//tmp->getCString());
      fprintf(page, "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=%s\">\n", globalParams->getTextEncodingName()->getCString());
      fprintf(page, "%s\n", GENERATOR);
      dumpMetaVars(page);
      fprintf(page,"</head>\n");
      fprintf(page,"<body bgcolor=\"#A0A0A0>\" vlink=\"blue\" link=\"blue\">\n");
    }
  }    
  
  //delete tmp;
}

HtmlOutputDev::~HtmlOutputDev() {
  /*if (mode&&!xml){
    int h=xoutRound(pages->pageHeight/scale);
    int w=xoutRound(pages->pageWidth/scale);
    fprintf(tin,"%s=%03d\n","PAPER_WIDTH",w);
    fprintf(tin,"%s=%03d\n","PAPER_HEIGHT",h);
    fclose(tin);
    }*/

    HtmlFont::clear(); 
    if ( glMetaVars != NULL )
      deleteGList(glMetaVars, HtmlMetaVar /*template type*/);
    delete Docname;
    delete docTitle;

    if (f){
      fputs("</body>\n</html>\n",f);  
      fclose(f);
    }
    if (xml) {
      fputs("</pdf2xml>\n",page);  
      fclose(page);
    } else
    if (!mode||xml){ 
      fputs("</body>\n</html>\n",page);  
      fclose(page);
    }
    if (pages)
      delete pages;
}



void HtmlOutputDev::startPage(int pageNum, GfxState *state) {
  /*if (mode&&!xml){
    if (write){
      write=gFalse;
      GString* fname=Dirname(Docname);
      fname->append("image.log");
      if((tin=fopen(fname->getCString(),"w"))==NULL){
	printf("Error : can not open %s",fname);
	exit(1);
      }
      delete fname;
    // if(state->getRotation()!=0) 
    //  fprintf(tin,"ROTATE=%d rotate %d neg %d neg translate\n",state->getRotation(),state->getX1(),-state->getY1());
    // else 
      fprintf(tin,"ROTATE=%d neg %d neg translate\n",state->getX1(),state->getY1());  
    }
  }*/

  GString *str=basename(Docname);
  pages->clear(); 
    if(!noframes){
      if (f){
	if (mode)
	  fprintf(f,"<a href=\"%s-%d.html\"",str->getCString(),pageNum);
	else 
	  fprintf(f,"<a href=\"%ss.html#%d\"",str->getCString(),pageNum);
	fprintf(f," target=\"rechts\" >Page %d</a>\n",pageNum);
      }
    }
    delete str;
} 


void HtmlOutputDev::endPage() {
  pages->coalesce();
  pages->conv();
  pages->dump(page, docTitle);
  
  // I don't yet know what to do in the case when there are pages of different
  // sizes and we want complex output: running ghostscript many times 
  // seems very inefficient. So for now I'll just use last page's size
  maxPageWidth = pages->pageWidth;
  maxPageHeight = pages->pageHeight;
  // reset page width and height so that it will be updated for the new page
  pages->pageWidth=0;
  pages->pageHeight=0;
  
if(!noframes&&!xml) fputs("<br>", f);
  if(!stout && !globalParams->getErrQuiet()) printf("Page-%d\n",(pageNum));
  pageNum++ ;
}

void HtmlOutputDev::updateFont(GfxState *state) {
  pages->updateFont(state);
}

void HtmlOutputDev::beginString(GfxState *state, GString *s) {
  pages->beginString(state, s);
}

void HtmlOutputDev::endString(GfxState *state) {
  pages->endString();
}

void HtmlOutputDev::drawChar(GfxState *state, double x, double y,
	      double dx, double dy,
	      double originX, double originY,
	      CharCode code, Unicode *u, int uLen) 
{
  // Don't display text that is only used for clipping (rendering mode 7).
  // Removing invisible text (rendering mode 3) may seem like a good idea
  // at first.  However, invisible text has some good uses, e.g., OCR
  // text behind a scanned image.  ACM and IEEECS use this trick for their
  // older papers.  So, we choose to extract and output invisible text.
  if (state->getRender() == 7) {
    return;
  }

#if 0
  fprintf(stderr, "x: %f y: %f, dx: %f  dy: %f origX: %f origY: %f CharCode: %c Unicode: ", 
          x, y, dx, dy, originX, originY, code);
  for (int i = 0; i < uLen; ++i) {
    fprintf(stderr, " %c", u[i]);
  }
  fprintf(stderr, "\n");
#endif

  // Prior version used addChars.
  // pages->addChars(state, x, y, dx, dy, u, uLen);
  pages->addChar(state, x, y, dx, dy, u, uLen);
}

void HtmlOutputDev::drawImageMask(GfxState *state, Object *ref, Stream *str,
			      int width, int height, GBool invert,
			      GBool inlineImg) {
#ifdef USE_ORIGINAL_CODE
  { // Is this a horizontal line?  If so, we don't need an image.
    double x, y, dx, dy;
    state->transform(0, 0, &x, &y);
    state->transformDelta(width, height, &dx, &dy);
    if (pages->maybeAddHR(state, x, y, dx, dy)) {
      return;
    }
  }

  int i, j;
  
  if (ignore||mode) {
    OutputDev::drawImageMask(state, ref, str, width, height, invert, inlineImg);
    return;
  }
  
  FILE *f1;
  int c;
  
  int x0, y0;			// top left corner of image
  int w0, h0, w1, h1;		// size of image
  double xt, yt, wt, ht;
  GBool rotate, xFlip, yFlip;
  GBool dither;
  int x, y;
  int ix, iy;
  int px1, px2, qx, dx;
  int py1, py2, qy, dy;
  Gulong pixel;
  int nComps, nVals, nBits;
  double r1, g1, b1;
 
  // get image position and size
  state->transform(0, 0, &xt, &yt);
  state->transformDelta(1, 1, &wt, &ht);
  if (wt > 0) {
    x0 = xoutRound(xt);
    w0 = xoutRound(wt);
  } else {
    x0 = xoutRound(xt + wt);
    w0 = xoutRound(-wt);
  }
  if (ht > 0) {
    y0 = xoutRound(yt);
    h0 = xoutRound(ht);
  } else {
    y0 = xoutRound(yt + ht);
    h0 = xoutRound(-ht);
  }
  state->transformDelta(1, 0, &xt, &yt);
  rotate = fabs(xt) < fabs(yt);
  if (rotate) {
    w1 = h0;
    h1 = w0;
    xFlip = ht < 0;
    yFlip = wt > 0;
  } else {
    w1 = w0;
    h1 = h0;
    xFlip = wt < 0;
    yFlip = ht > 0;
  }

  // dump JPEG file
  if (dumpJPEG  && str->getKind() == strDCT) {
    GString *fName=new GString(Docname);
    fName->append("-");
    GString *pgNum=GString::fromInt(pageNum);
    GString *imgnum=GString::fromInt(imgNum);
    // open the image file
    fName->append(pgNum)->append("_")->append(imgnum)->append(".jpg");
    ++imgNum;
    if (!(f1 = fopen(fName->getCString(), "wb"))) {
      error(-1, "Couldn't open image file '%s'", fName->getCString());
      return;
    }

    // initialize stream
    str = ((DCTStream *)str)->getRawStream();
    str->reset();

    // copy the stream
    while ((c = str->getChar()) != EOF)
      fputc(c, f1);

    fclose(f1);
   
  if (pgNum) delete pgNum;
  if (imgnum) delete imgnum;
  if (fName) delete fName;
  }
  else {
    OutputDev::drawImageMask(state, ref, str, width, height, invert, inlineImg);
  }
#else   // USE_ORIGINAL_CODE
  OutputDev::drawImageMask(state, ref, str, width, height, invert, inlineImg);
#endif  // USE_ORIGINAL_CODE
}

void HtmlOutputDev::drawImage(GfxState *state, Object *ref, Stream *str,
			  int width, int height, GfxImageColorMap *colorMap,
			  int *maskColors, GBool inlineImg) {
#ifdef USE_ORIGINAL_IMAGE
  { // Is this a horizontal line?  If so, we don't need an image.
    double x, y, dx, dy;
    state->transform(0, 0, &x, &y);
    state->transformDelta(width, height, &dx, &dy);
    if (pages->maybeAddHR(state, x, y, dx, dy)) {
      return;
    }
  }

  int i, j;
   
  if (ignore||mode) {
    OutputDev::drawImage(state, ref, str, width, height, colorMap, 
			 maskColors, inlineImg);
    return;
  }

  FILE *f1;
  ImageStream *imgStr;
  Guchar pixBuf[4];
  GfxColor color;
  int c;
  
  int x0, y0;			// top left corner of image
  int w0, h0, w1, h1;		// size of image
  double xt, yt, wt, ht;
  GBool rotate, xFlip, yFlip;
  GBool dither;
  int x, y;
  int ix, iy;
  int px1, px2, qx, dx;
  int py1, py2, qy, dy;
  Gulong pixel;
  int nComps, nVals, nBits;
  double r1, g1, b1;
 
  // get image position and size
  state->transform(0, 0, &xt, &yt);
  state->transformDelta(1, 1, &wt, &ht);
  if (wt > 0) {
    x0 = xoutRound(xt);
    w0 = xoutRound(wt);
  } else {
    x0 = xoutRound(xt + wt);
    w0 = xoutRound(-wt);
  }
  if (ht > 0) {
    y0 = xoutRound(yt);
    h0 = xoutRound(ht);
  } else {
    y0 = xoutRound(yt + ht);
    h0 = xoutRound(-ht);
  }
  state->transformDelta(1, 0, &xt, &yt);
  rotate = fabs(xt) < fabs(yt);
  if (rotate) {
    w1 = h0;
    h1 = w0;
    xFlip = ht < 0;
    yFlip = wt > 0;
  } else {
    w1 = w0;
    h1 = h0;
    xFlip = wt < 0;
    yFlip = ht > 0;
  }

   
  /*if( !globalParams->getErrQuiet() )
    printf("image stream of kind %d\n", str->getKind());*/
  // dump JPEG file
  if (dumpJPEG && str->getKind() == strDCT) {
    GString *fName=new GString(Docname);
    fName->append("-");
    GString *pgNum= GString::fromInt(pageNum);
    GString *imgnum= GString::fromInt(imgNum);  
    
    // open the image file
    fName->append(pgNum)->append("_")->append(imgnum)->append(".jpg");
    ++imgNum;
    
    if (!(f1 = fopen(fName->getCString(), "wb"))) {
      error(-1, "Couldn't open image file '%s'", fName->getCString());
      return;
    }

    // initialize stream
    str = ((DCTStream *)str)->getRawStream();
    str->reset();

    // copy the stream
    while ((c = str->getChar()) != EOF)
      fputc(c, f1);
    
    fclose(f1);
  
    delete fName;
    delete pgNum;
    delete imgnum;
  }
  else {
    OutputDev::drawImage(state, ref, str, width, height, colorMap,
			 maskColors, inlineImg);
  }
#else // USE_ORIGINAL_CODE
  OutputDev::drawImage(state, ref, str, width, height, colorMap,
			maskColors, inlineImg);
#endif // USE_ORIGINAL_CODE
}



void HtmlOutputDev::drawLink(Link* link,Catalog *cat){
  double _x1,_y1,_x2,_y2;
  int x1,y1,x2,y2;
  
  link->getRect(&_x1,&_y1,&_x2,&_y2);
  cvtUserToDev(_x1,_y1,&x1,&y1);
  
  cvtUserToDev(_x2,_y2,&x2,&y2); 


  GString* _dest=getLinkDest(link,cat);
  HtmlLink t((double) x1,(double) y2,(double) x2,(double) y1,_dest);
  pages->AddLink(t);
  delete _dest;
}

GString *HtmlOutputDev::getLinkDest(Link *link,Catalog* catalog){
  char *p;
  switch(link->getAction()->getKind()) {
  case actionGoTo:{ 
    GString* file= (stdout ? new GString() : basename(Docname));
    int page=1;
    LinkGoTo *ha=(LinkGoTo *)link->getAction();
    LinkDest *dest=NULL;
    if (ha->getDest()==NULL) dest=catalog->findDest(ha->getNamedDest());
    else dest=ha->getDest()->copy();
    if (dest){ 
      if (dest->isPageRef()){
	Ref pageref=dest->getPageRef();
	page=catalog->findPage(pageref.num,pageref.gen);
      }
      else {
	page=dest->getPageNum();
      }
      
      delete dest;

      GString *str=GString::fromInt(page);
      if (mode) file->append("-");
      else if (googlemode)
        file->append("#");
      else{ 
	if (!noframes) file->append("s");
	file->append(".html#");
      }
      file->append(str);
      if (mode) file->append(".html");
      if (printCommands) printf(" page %d ",page);
      delete str;
      return file;
    }
    else return new GString();
  }
  
  case actionGoToR:{              
    LinkGoToR *ha=(LinkGoToR *) link->getAction();
    LinkDest *dest=NULL;
    int page=1;
    GString *file=new GString();
    if (ha->getFileName()){
      delete file;
      file=new GString(ha->getFileName()->getCString());
    }
    if (ha->getDest()!=NULL)  dest=ha->getDest()->copy();
    if (dest&&file){
      if (!(dest->isPageRef()))  page=dest->getPageNum();
      delete dest;

      if (printCommands) printf(" page %d ",page);
      if (printHtml){
	p=file->getCString()+file->getLength()-4;
	if (!strcmp(p, ".pdf") || !strcmp(p, ".PDF")){
	  file->del(file->getLength()-4,4);
	  file->append(".html");
	}
	file->append('#');
	file->append(GString::fromInt(page));
      }
    }
    if (printCommands) printf("filename %s\n",file->getCString());
    return file;
  }
  case actionURI: {
    LinkURI *ha=(LinkURI *) link->getAction();
    GString* file=new GString(ha->getURI()->getCString());
    // printf("uri : %s\n",file->getCString());
    return file;
  }
       
  case actionLaunch: {
    LinkLaunch *ha=(LinkLaunch *) link->getAction();
    GString* file=new GString(ha->getFileName()->getCString());
    if (printHtml) { 
      p=file->getCString()+file->getLength()-4;
      if (!strcmp(p, ".pdf") || !strcmp(p, ".PDF")){
	file->del(file->getLength()-4,4);
	file->append(".html");
      }
      if (printCommands) printf("filename %s",file->getCString());
    }
    return file;      
  }
  default:
    return new GString();
  }
}

void HtmlOutputDev::dumpMetaVars(FILE *file) {
  if ( glMetaVars == NULL )
    return;

  GString *var;
  for ( int i = 0; i < glMetaVars->getLength(); i++ ) {
     HtmlMetaVar *t = (HtmlMetaVar*)glMetaVars->get(i); 
     var = t->toString();
     fprintf(file, "%s\n", var->getCString());
     delete var;
  }
}
