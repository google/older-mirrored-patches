/* Modified from v0.33 on Feb 17, 2005 by Google */
#include "HtmlFonts.h"
#include "GlobalParams.h"
#include "UnicodeMap.h"
#include "GfxFont.h"
#include <stdio.h>
#include <ctype.h>

 struct Fonts{
    char *Fontname;
    char *name;
  };

  static Fonts fonts[]={  
     {"Courier",               "Courier" },
     {"Courier-Bold",           "Courier"},
     {"Courier-BoldOblique",    "Courier"},
     {"Courier-Oblique",        "Courier"},
     {"Helvetica",              "Times"},  // Helvetica font is buggy in 
     {"Helvetica-Bold",         "Times"},  // UTF-8 on Netscape 4.7 on Linux,
     {"Helvetica-BoldOblique",  "Times"},  // Use Times instead
     {"Helvetica-Oblique",      "Times"},
     {"Symbol",                 "Symbol"   },
     {"Times-Bold",             "Times"    },
     {"Times-BoldItalic",       "Times"    },
     {"Times-Italic",           "Times"    },
     {"Times-Roman",            "Times"    },
     {" "          ,            "Times"    },
};

int HtmlFont::leak=0;
#define xoutRound(x) ((int)(x + 0.5))
extern GBool xml;

const int font_num=13;
GString* HtmlFont::DefaultFont=new GString("Times"); // Arial,Helvetica,sans-serif

HtmlFontColor::HtmlFontColor(GfxRGB rgb){
  r=static_cast<int>(255*rgb.r);
  g=static_cast<int>(255*rgb.g);
  b=static_cast<int>(255*rgb.b);
  if (!(Ok(r)&&Ok(b)&&Ok(g))) {printf("Error : Bad color \n");r=0;g=0;b=0;}
}

GString *HtmlFontColor::convtoX(unsigned int xcol) const{
  GString *xret=new GString();
  char tmp;
  unsigned  int k;
  k = (xcol/16);
  if ((k>=0)&&(k<10)) tmp=(char) ('0'+k); else tmp=(char)('a'+k-10);
  xret->append(tmp);
  k = (xcol%16);
  if ((k>=0)&&(k<10)) tmp=(char) ('0'+k); else tmp=(char)('a'+k-10);
  xret->append(tmp);
 return xret;
}

GString *HtmlFontColor::toString() const{
  GString *tmp=new GString("#");
  GString *tmpr=convtoX(r); 
  GString *tmpg=convtoX(g);
  GString *tmpb=convtoX(b);
  tmp->append(tmpr);
  tmp->append(tmpg);
  tmp->append(tmpb);
  delete tmpr;
  delete tmpg;
  delete tmpb;
  return tmp;
} 

HtmlFont::HtmlFont(GfxFont* font, int fontSize, GfxRGB rgb) {
  if (DefaultFont == NULL) {
    DefaultFont = new GString(fonts[font_num].name);
  }

  leak++;
  color = HtmlFontColor(rgb);
  size = fontSize;
  if (font != NULL) {
    FontName = (font->getName() == NULL) ?
                 new GString(DefaultFont) :
                 new GString(font->getName());
    italic = font->isItalic();
    bold = font->isBold();
  } else {
    FontName = new GString(DefaultFont);
    italic = false;
    bold = false;
  }

  // Sometimes, bold/italic fonts are not marked as such.
  // HACK: try to guess bold/italic from the font name.
  {
    GString* const fn = new GString(FontName);
    fn->lowerCase();
    const int n = fn->getLength();
    bold =
      bold ||
      strstr(fn->getCString(), "bold") != NULL ||
      strstr(fn->getCString(), "_tib") != NULL ||
      (n >= 2 && fn->getChar(n - 2) == '-' && fn->getChar(n - 1) == 'b') ||
      (n >= 2 && fn->getChar(n - 2) == '.' && fn->getChar(n - 1) == 'b') ||
      (n >= 2 && fn->getChar(n - 2) == 'b' && fn->getChar(n - 1) == 'c');
    italic =
      italic ||
      strstr(fn->getCString(), "italic") != NULL ||
      strstr(fn->getCString(), "oblique") != NULL ||
      strstr(fn->getCString(), "_tii") != NULL ||
      (n >= 2 && fn->getChar(n - 2) == '-' && fn->getChar(n - 1) == 'i') ||
      (n >= 2 && fn->getChar(n - 2) == '.' && fn->getChar(n - 1) == 'i');
    delete fn;
  }

  // Look for this font in the fonts array.
  pos = 0;
  while (pos < font_num &&
         strcmp(FontName->getCString(), fonts[pos].Fontname)) {
    ++pos;
  }
}

HtmlFont::HtmlFont(const HtmlFont& x) {
  leak++;
  FontName = NULL;
  operator=(x);
}

HtmlFont::~HtmlFont() {
  leak--;
  delete FontName;
  FontName = NULL;
}

HtmlFont& HtmlFont::operator=(const HtmlFont& x) {
  if (this==&x) return *this; 
  size=x.size;
  italic=x.italic;
  bold=x.bold;
  pos=x.pos;
  color=x.color;
  delete FontName;
  FontName = (x.FontName == NULL) ? NULL : new GString(x.FontName);
  return *this;
}

void HtmlFont::clear() {
  delete DefaultFont;
  DefaultFont = NULL;
}



/*
  This function is used to compare font uniquily for insertion into
  the list of all encountered fonts
*/
GBool HtmlFont::isEqual(const HtmlFont& x) const{
  return ((size==x.size) &&
	  (pos==x.pos) &&  // this comparison covers italic/bold
	  (isBold() == x.isBold()) && (isItalic() == x.isItalic()) &&
          (color.isEqual(x.getColor())));
}

/*
  This one is used to decide whether two pieces of text can be joined together
  and therefore we don't care about bold/italics properties
*/
GBool HtmlFont::isEqualIgnoreBold(const HtmlFont& x) const{
  return ((size==x.size) &&
	  (!strcmp(fonts[pos].name, fonts[x.pos].name)) &&
	  (color.isEqual(x.getColor())));
}

GString* HtmlFont::getFontName(){
   if (pos!=font_num) return new GString(fonts[pos].name);
    else return new GString(DefaultFont);
}

GString* HtmlFont::getFullName(){
  if (FontName)
    return new GString(FontName);
  else return new GString(DefaultFont);
} 

void HtmlFont::setDefaultFont(GString* defaultFont){
  if (DefaultFont) delete DefaultFont;
  DefaultFont=new GString(defaultFont);
}


GString* HtmlFont::getDefaultFont(){
  return DefaultFont;
}

// this method if plain wrong todo
GString* HtmlFont::HtmlFilter(Unicode* u, int uLen) {
  GString *tmp = new GString();
  UnicodeMap *uMap;
  char buf[8];
  int n;

  // get the output encoding
  if (!(uMap = globalParams->getTextEncoding())) {
    return NULL;
  }

  for (int i = 0; i < uLen; ++i) {
    switch (u[i])
      {  
        // serious hack, probably UTF-8 only, but mozilla doesn't do too well 
        // on ligatures, get rid of them
        case 0xFB00: tmp->append("ff"); break;
        case 0xFB01: tmp->append("fi"); break;
        case 0xFB02: tmp->append("fl"); break;
        case 0xFB03: tmp->append("ffi"); break;
        case 0xFB04: tmp->append("ffl"); break;

	case '"': tmp->append("&quot;");  break;
	case '&': tmp->append("&amp;");  break;
	case '<': tmp->append("&lt;");  break;
	case '>': tmp->append("&gt;");  break;
	default:  
	  {
	    // convert unicode to string
	    if ((n = uMap->mapUnicode(u[i], buf, sizeof(buf))) > 0) {
	      tmp->append(buf, n); 
	  }
      }
    }
  }

  uMap->decRefCnt();
  return tmp;
}

GString* HtmlFont::simple(HtmlFont font, Unicode* content, int uLen){
  GString *cont=HtmlFilter (content, uLen); 

  /*if (font.isBold()) {
    cont->insert(0,"<b>",3);
    cont->append("</b>",4);
  }
  if (font.isItalic()) {
    cont->insert(0,"<i>",3);
    cont->append("</i>",4);
    } */

  return cont;
}

// Maps from [letter][accent] to the Unicode symbol.  See join() below.
// This table is obviously incomplete -- Unicode is huge!  We cover
// all of Latin1 plus a few characters from Latin Extended-A.  Feel free
// to add more combinations if you need them.
/* static */
Unicode HtmlFont::joinMap[19][9] = {
  //    tilde dieresis  acute cedilla circumflex caron  grave   ring
  { 0,      0,      0,      0,      0,      0,      0,      0,      0 },
  { 0,  0x0C3,  0x0C4,  0x0C1,      0,  0x0C2,      0,  0x0C0,  0x0C5 }, // A
  { 0,      0,      0,      0,  0x0C7,      0,      0,      0,      0 }, // C
  { 0,      0,  0x0CB,  0x0C9,      0,  0x0CA,      0,  0x0C8,      0 }, // E
  { 0,      0,  0x0CF,  0x0CD,      0,  0x0CE,      0,  0x0CC,      0 }, // I
  { 0,  0x0D1,      0,      0,      0,      0,      0,      0,      0 }, // N
  { 0,  0x0D5,  0x0D6,  0x0D3,      0,  0x0D4,      0,  0x0D2,      0 }, // O
  { 0,      0,      0,      0,      0,      0,  0x160,      0,      0 }, // S
  { 0,      0,  0x0DC,  0x0DA,      0,  0x0DB,      0,  0x0D9,      0 }, // U
  { 0,      0,  0x178,  0x0DD,      0,      0,      0,      0,      0 }, // Y

  { 0,  0x0E3,  0x0E4,  0x0E1,      0,  0x0E2,      0,  0x0E0,  0x0E5 }, // a
  { 0,      0,      0,      0,  0x0E7,      0,      0,      0,      0 }, // c
  { 0,      0,  0x0EB,  0x0E9,      0,  0x0EA,      0,  0x0E8,      0 }, // e
  { 0,      0,  0x0EF,  0x0ED,      0,  0x0EE,      0,  0x0EC,      0 }, // i
  { 0,  0x0F1,      0,      0,      0,      0,      0,      0,      0 }, // n
  { 0,  0x0F5,  0x0F6,  0x0F3,      0,  0x0F4,      0,  0x0F2,      0 }, // o
  { 0,      0,      0,      0,      0,      0,  0x161,      0,      0 }, // s
  { 0,      0,  0x0FC,  0x0FA,      0,  0x0FB,      0,  0x0F9,      0 }, // u
  { 0,      0,  0x0FF,  0x0FD,      0,      0,      0,      0,      0 }, // y
};

/* static */
int HtmlFont::diacriticalIndex(Unicode x) {
  switch (x) {
    case '~': // tilde
      return 1;
    case 168: // dieresis
      return 2;
    case 180: // acute
      return 3;
    case 184: // cedilla
      return 4;
    case 710: // circumflex
      return 5;
    case 711: // caron
      return 6;
    case 715: // grave
      return 7;
    case 730: // ring
      return 8;
  }
  return 0;
}

// Should we join a and b into one unicode symbol?
// Used to normalize character drawing.  E.g., \"u can be drawn as
// one symbol \"u or two symbols: letter 'u' followed by a dieresis.
// Returns the code of the joined symbol, or zero if symbols should
// be separate.
/* static */
Unicode HtmlFont::join(Unicode a, Unicode b) {

  int i;
  switch (a) {

    // capital letters that can have accents
    case 'A':
      i = 1;
      break;
    case 'C':
      i = 2;
      break;
    case 'E':
      i = 3;
      break;
    case 'I':
      i = 4;
      break;
    case 'N':
      i = 5;
      break;
    case 'O':
      i = 6;
      break;
    case 'S':
      i = 7;
      break;
    case 'U':
      i = 8;
      break;
    case 'Y':
      i = 9;
      break;

    // small letters that can have accents
    case 'a':
      i = 10;
      break;
    case 'c':
      i = 11;
      break;
    case 'e':
      i = 12;
      break;
    case 'i':
      i = 13;
      break;
    case 'n':
      i = 14;
      break;
    case 'o':
      i = 15;
      break;
    case 's':
      i = 16;
      break;
    case 'u':
      i = 17;
      break;
    case 'y':
      i = 18;
      break;

    // sentinel
    default:
      i = 0;
      break;
  }

  // lookup the answer, or zero if not a valid combination
  return joinMap[i][diacriticalIndex(b)];
}

HtmlFontAccu::HtmlFontAccu(){
  accu=new GVector<HtmlFont>();
}

HtmlFontAccu::~HtmlFontAccu(){
  if (accu) delete accu;
}

int HtmlFontAccu::AddFont(const HtmlFont& font){
 GVector<HtmlFont>::iterator i; 
 for (i=accu->begin();i!=accu->end();i++)
    if (font.isEqual(*i)) return (int)(i-(accu->begin())) ;
  accu->push_back(font);
  return (accu->size()-1);
}


GString* HtmlFontAccu::getCSStyle(int i,GString* content){
  GString *tmp;
  GString *iStr=GString::fromInt(i);

  if (!xml) {
    tmp = new GString("<span class=\"ft");
    tmp->append(iStr);
    tmp->append("\">");
    tmp->append(content);
    tmp->append("</span>");
  } else {
    tmp = new GString("");
    tmp->append(content);
  }

  delete iStr;
  return tmp;
}

GString* HtmlFontAccu::CSStyle(int i){
   GString *tmp=new GString();
   GString *iStr=GString::fromInt(i);

   GVector<HtmlFont>::iterator g=accu->begin();
   g+=i;
   HtmlFont font=*g;
   GString *Size=GString::fromInt(font.getSize());
   GString *colorStr=font.getColor().toString();
   GString *fontName=font.getFontName();

   if(!xml){
     tmp->append(".ft");
     tmp->append(iStr);
     tmp->append("{font-size:");
     tmp->append(Size);
     tmp->append("px;font-family:");
     tmp->append(fontName); //font.getFontName());
     tmp->append(";color:");
     tmp->append(colorStr);
     tmp->append(";}");
   }
   if (xml) {
     tmp->append("<fontspec id=\"");
     tmp->append(iStr);
     tmp->append("\" size=\"");
     tmp->append(Size);
     tmp->append("\" family=\"");
     tmp->append(fontName); //font.getFontName());
     tmp->append("\" color=\"");
     tmp->append(colorStr);
     tmp->append("\"/>");
   }

   delete fontName;
   delete colorStr;
   delete iStr;
   delete Size;
   return tmp;
}
 
