/* Modified from v0.33 on Feb 17, 2005 by Google */
//========================================================================
//
// HtmlOutputDev.h
//
// Copyright 1997 Derek B. Noonburg
//
// Changed 1999 by G.Ovtcharov
//========================================================================

#ifndef HTMLOUTPUTDEV_H
#define HTMLOUTPUTDEV_H

#ifdef __GNUC__
#pragma interface
#endif

#include <stdio.h>
#include "gtypes.h"
#include "GfxFont.h"
#include "OutputDev.h"
#include "HtmlLinks.h"
#include "HtmlFonts.h"
#include "Link.h"
#include "Catalog.h"


#ifdef WIN32
#  define SLASH '\\'
#else
#  define SLASH '/'
#endif

#define xoutRound(x) ((int)(x + 0.5))

#define GENERATOR "<meta NAME=\"GENERATOR\" CONTENT=\"pdftohtml 0.33a\">"

class GfxState;
class GString;
class GList;

//------------------------------------------------------------------------
// HtmlString
//------------------------------------------------------------------------



class HtmlString {
public:

  // Constructor.
  HtmlString(GfxState *state, double fontSize, HtmlFontAccu* fonts);

  // Destructor.
  ~HtmlString();

  // Add characters to the string.
  void addChars(GfxState *state, double x, double y,
	        double dx, double dy,
	        Unicode *u, int uLen); 

private:
// aender die text variable
  double xMin, xMax;		// bounding box x coordinates
  double yMin, yMax;		// bounding box y coordinates
  Unicode *text;		// the text
  HtmlString *yxNext;		// next string in y-major order
  HtmlString *xyNext;		// next string in x-major order
  int fontpos;
  GString* htext;
  int len;			// length of text
  int size;			// size of text array
  GBool mergeNext;
  GBool escape;                 // do we need to escape/encode contents?
  
  friend class HtmlPage;

};


//------------------------------------------------------------------------
// HtmlPage
//------------------------------------------------------------------------



class HtmlPage {
public:

  // Constructor.
  HtmlPage(GBool rawOrder, GBool printHR);

  // Destructor.
  ~HtmlPage();

  // Begin a new string.
  void beginString(GfxState *state, GString *s);

  // Add a character to the current string.
  void addChar(GfxState *state, double x, double y,
	       double dx, double dy, Unicode *u, int uLen);

  void updateFont(GfxState *state);

  // Add a path.  We draw some paths with <hr>.
  void addPath(GfxState *state);

  // Add a rectangle to be drawn as <hr>.  Returns false if not horizontal.
  bool maybeAddHR(GfxState *state, double x, double y, double dx, double dy);

  // End the current string, sorting it into the list of strings.
  void endString();

  // Coalesce strings that look like parts of the same line.
  void coalesce();

  // Find a string.  If <top> is true, starts looking at top of page;
  // otherwise starts looking at <xMin>,<yMin>.  If <bottom> is true,
  // stops looking at bottom of page; otherwise stops looking at
  // <xMax>,<yMax>.  If found, sets the text bounding rectange and
  // returns true; otherwise returns false.
  

  // new functions
 

  
 
  void AddLink(const HtmlLink& x){
    links->AddLink(x);
  }

 void dump(FILE *f, GString *docTitle);

  // Clear the page.
  void clear();
  
  void conv();
private:
  HtmlFont getFont(HtmlString *hStr) { return fonts->Get(hStr->fontpos); }

  double fontSize;		// current font size
  GBool rawOrder;		// keep strings in content stream order
  GBool printHR;                // print horizontal rules

  HtmlString *curStr;		// currently active string

  HtmlString *yxStrings;	// strings in y-major order
  HtmlString *xyStrings;	// strings in x-major order
  HtmlString *yxCur1, *yxCur2;	// cursors for yxStrings list
  
  void setDocName(char* fname);
  void dumpAsXML(FILE* f,int page);
  void dumpComplex(int page);
  void dumpGoogle(int nump, FILE *f, GString *docTitle);

  void setFont(FILE *f, HtmlFont *font);
  void endFont(FILE *f);
  void setSubFont(FILE *f, HtmlFont *oldfont, HtmlFont *font);
  void endSubFont(FILE *f);
  void setPos(FILE *f, int yoffset, HtmlString *htmlstring);
  void endPos(FILE *f);
  GBool dgte(double arg1, double arg2);
  GBool deq(double arg1, double arg2);
  GBool isEmpty(GString *str);
 
  HtmlFontAccu *fonts;
  HtmlLinks *links; 
  
  GString* DocName;
  int pageWidth;
  int pageHeight;
  static int pgNum;

  friend class HtmlOutputDev;
};

//------------------------------------------------------------------------
// HtmlMetaVar: represent one meta tag
//------------------------------------------------------------------------
class HtmlMetaVar {
public:
  HtmlMetaVar(char *_name, char *_content);
  ~HtmlMetaVar();    
    
  // caller has to delete the returned object.
  GString* toString();	

private:

  GString *name;
  GString *content;
};

//------------------------------------------------------------------------
// HtmlOutputDev
//------------------------------------------------------------------------

class HtmlOutputDev: public OutputDev {
public:

  // Open a text output file.  If <fileName> is NULL, no file is written
  // (this is useful, e.g., for searching text).  If <useASCII7> is true,
  // text is converted to 7-bit ASCII; otherwise, text is converted to
  // 8-bit ISO Latin-1.  <useASCII7> should also be set for Japanese
  // (EUC-JP) text.  If <rawOrder> is true, the text is kept in content
  // stream order.
  // <glMetaVars> is transfered ownership here. Caller must not delete it.
  HtmlOutputDev(char *fileName, GString *title, GList *glMetaVars, 
                GBool rawOrder, GBool printHR);

  // Destructor.
  virtual ~HtmlOutputDev();

  // Check if file was successfully created.
  virtual GBool isOk() { return ok; }

  //---- get info about output device

  // Does this device use upside-down coordinates?
  // (Upside-down means (0,0) is the top left corner of the page.)
  virtual GBool upsideDown() { return gTrue; }

  // Does this device use drawChar() or drawString()?
  virtual GBool useDrawChar() { return gTrue; }

  //----- initialization and control

  // Start a page.
  virtual void startPage(int pageNum, GfxState *state);

  // End a page.
  virtual void endPage();

  //----- update text state
  virtual void updateFont(GfxState *state);

  //----- text drawing
  virtual void beginString(GfxState *state, GString *s);
  virtual void endString(GfxState *state);
  virtual void drawChar(GfxState *state, double x, double y,
			double dx, double dy,
			double originX, double originY,
			CharCode code, Unicode *u, int uLen);
  
  virtual void drawImageMask(GfxState *state, Object *ref, 
			     Stream *str,
			     int width, int height, GBool invert,
			     GBool inlineImg);
  virtual void drawImage(GfxState *state, Object *ref, Stream *str,
			  int width, int height, GfxImageColorMap *colorMap,
			 int *maskColors, GBool inlineImg);
  virtual void stroke(GfxState *state) { pages->addPath(state); }
  virtual void fill(GfxState *state) { pages->addPath(state); }
  virtual void eoFill(GfxState *state) { pages->addPath(state); }

  //new feature    
  virtual int DevType() {return 1234;}
  virtual void drawLink(Link *link,Catalog *cat); 

  int getPageWidth() { return maxPageWidth; }
  int getPageHeight() { return maxPageHeight; }

  // Does this device use beginType3Char/endType3Char?  Otherwise,
  // text in Type 3 fonts will be drawn with drawChar/drawString.
  virtual GBool interpretType3Chars() { return gFalse; }

private:

  GString* getLinkDest(Link *link,Catalog *catalog);
  void dumpMetaVars(FILE *);
  void doFrame();
  FILE *f;			// text file
  FILE *page;                   // html file
  //FILE *tin;                    // image log file
  //GBool write;
  GBool needClose;		// need to close the file?
  HtmlPage *pages;		// text for the current page
  GBool rawOrder;		// keep text in content stream order
  GBool ok;			// set up ok?
  GBool dumpJPEG;
  int pageNum;
  int maxPageWidth;
  int maxPageHeight;
  static int imgNum;
  GString *Docname;
  GString *docTitle;
  GList *glMetaVars;
  friend class HtmlPage;
};

#endif
