/* Modified from v0.33 on Feb 17, 2005 by Google */
//========================================================================
//
// pdftohtml.cc
//
//
// Copyright 1999-2000 G. Ovtcharov
//========================================================================

#include <stdio.h>
#include <stdlib.h>
#include <stddef.h>
#include <string.h>
#include <aconf.h>
#include <errno.h>
#include "parseargs.h"
#include "GString.h"
#include "GList.h"
#include "gmem.h"
#include "Object.h"
#include "Stream.h"
#include "Array.h"
#include "Dict.h"
#include "XRef.h"
#include "Catalog.h"
#include "Page.h"
#include "PDFDoc.h"
#include "HtmlOutputDev.h"
#include "PSOutputDev.h"
#include "GlobalParams.h"
#include "Error.h"
#include "config.h"
#include "gfile.h"

#define GHOSTSCRIPT "gs"

#ifdef WIN32
#define PATH_MAX MAX_PATH
#endif

// decide which characters need to be escaped
const unsigned char needs_escaping[] = {
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
  1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1,  // 0-9
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0,  // A-Z _
  1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1,  // a-z
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  // 0x80 -
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,  
  0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1,  // 0xfe
};

static int firstPage = 1;
static int lastPage = 0;
static GBool rawOrder = gTrue;
GBool printCommands = gTrue;
static GBool printHelp = gFalse;
GBool printHtml = gFalse;
GBool mode=gFalse;
GBool googlemode=gFalse;
GBool ignore=gFalse;
char extension[5]=".png";
double scale=1.5;
GBool noframes=gFalse;
GBool printHR = gFalse;
GBool stout=gFalse;
GBool xml=gFalse;
GBool errQuiet=gFalse;
static char ownerPassword[33] = "";
static char userPassword[33] = "";
static GBool printVersion = gFalse;
GBool noArchive=gFalse;

static GString* getInfoString(Dict *infoDict, char *key);

static char textEncName[128] = "";

extern char langConfigDir[2048];

static char temp_dir[PATH_MAX];

static int maxNumPages = -1;

static ArgDesc argDesc[] = {
  {"-f",      argInt,      &firstPage,     0,
   "first page to convert"},
  {"-l",      argInt,      &lastPage,      0,
   "last page to convert"},
  /*{"-raw",    argFlag,     &rawOrder,      0,
    "keep strings in content stream order"},*/
  /*#if JAPANESE_SUPPORT
  {"-eucjp",  argFlag,     &useEUCJP,      0,
   "convert Japanese text to EUC-JP"},
   #endif*/
  {"-q",      argFlag,     &errQuiet,      0,
   "don't print any messages or errors"},
  {"-h",      argFlag,     &printHelp,     0,
   "print usage information"},
  {"-help",   argFlag,     &printHelp,     0,
   "print usage information"},
  {"-p",      argFlag,     &printHtml,     0,
   "exchange .pdf links by .html"}, 
  {"-c",      argFlag,     &mode,          0,
   "generate complex document"},
  {"-g",      argFlag,     &googlemode,    0,
   "generate google-type document"},
  {"-i",      argFlag,     &ignore,        0,
   "ignore images"},
  {"-noframes", argFlag,   &noframes,      0,
   "generate no frames"},
  {"-hr",     argFlag,     &printHR,       0,
   "generate horizontal rules"},
  {"-stdout"  ,argFlag,    &stout,         0,
   "use standard output"},
  {"-zoom"   ,argFP,    &scale,         0,
   "zoom the pdf document (default 1.5)"},
  {"-xml"  ,argFlag,    &xml,         0,
   "output for XML post-processing"},
  {"-enc",    argString,   textEncName,    sizeof(textEncName),
   "output text encoding name"},
  {"-v",      argFlag,     &printVersion,  0,
   "print copyright and version info"},
  {"-opw",    argString,   ownerPassword,  sizeof(ownerPassword),
   "owner password (for encrypted files)"},
  {"-upw",    argString,   userPassword,   sizeof(userPassword),
   "user password (for encrypted files)"},
  {"-lang",    argString,   langConfigDir,   sizeof(langConfigDir),
   "directory containing information for configuring languages"},
  {"-t",    argString,   temp_dir,   sizeof(temp_dir),
   "directory for temporary files"},
  {"-pages",   argInt,    &maxNumPages,    -1,
   "maximum number of pages to convert default -1(all)"},
  {NULL}
};

// canonicalizeMetaTagName():
//    Some meta tags have format of "XX.YYY" or "XX.YYY.ZZ ZZZ"
//    This function is to put meta tag name in some normal form
//    that is more convenient for metatag search.
static char* canonicalizeMetaTagName(const char *metaName, char *buffer, int bufferLen) {
  char *firstDot;
  memset(buffer, 0, bufferLen);
  if ( (firstDot = strchr(metaName, '.')) != NULL )
    strncpy(buffer, firstDot+1, bufferLen-1);
  else
    strncpy(buffer, metaName, bufferLen-1);

  char *cptr = buffer;
  while ( *cptr != 0 ) {
    if ( needs_escaping[*cptr] )
      *cptr = '_';
    cptr++;
  }
  return buffer;
}

// collectMetaTag():
//    Collect meta tags into a GList ready to print out to HTML.
//    Drop meta tags starting with "<254><255><0>" (ASCII values)
static GList* collectMetaData(Dict* dict) {
  GList* metaData = new GList();
  const int bufferLen = 256;
  char buffer[bufferLen];
  GString*  metaValue;

  // Type char is implementation dependent as to whether it is
  // signed or unsigned.  This code (used to) assume it is signed, but
  // gcc is defaulting it to unsigned.
  //
  // This is a bug fix independent of xpdf 2.0.3 upgrade.
  char MINUS1_CHAR = static_cast<char>(-1);
  char MINUS2_CHAR = static_cast<char>(-2);
  for ( int i = 0; i < dict->getLength() ; i++ ) {
    char *metaName  = dict->getKey(i);
 #ifdef WIN32
    if ( _stricmp(metaName, "Title") == 0)
#else 
    if ( strcasecmp(metaName, "Title") == 0)
#endif
      continue;
    metaValue = getInfoString(dict, metaName);
    if ( metaValue != NULL && (metaValue->getLength() != 0) &&
         ((metaValue->getLength() < 2) || (metaValue->getChar(0) != MINUS2_CHAR) ||
          (metaValue->getChar(1) != MINUS1_CHAR)) ) {
      metaData->append(new  
                       HtmlMetaVar(canonicalizeMetaTagName(metaName, buffer, bufferLen), 
                                   metaValue->getCString()));
    }
  }
  return metaData;
}

int main(int argc, char *argv[]) {

  // structured exception handling so we bow out gracefully on failures
#ifdef WIN32
  __try{
#endif
  PDFDoc *doc = NULL;
  GString *fileName = NULL;
  GString *docTitle = NULL;
  GString *htmlFileName = NULL;
  GString *psFileName = NULL;
  HtmlOutputDev *htmlOut = NULL;
  PSOutputDev *psOut = NULL;
  GBool ok;
  char *p;
  GString *ownerPW, *userPW;
  Object info;
  GList *glMetaVars = NULL;

  // parse args
  ok = parseArgs(argDesc, &argc, argv);
  if (!ok || argc < 2 || argc > 3 || printHelp || printVersion) {
    fprintf(stderr, "pdftohtml version %s http://pdftohtml.sourceforge.net/\n", "0.33a");
    fprintf(stderr, "%s\n", "Copyright 1999-2002 Gueorgui Ovtcharov and Rainer Dorsch");
    fprintf(stderr, "based on Xpdf version %s\n", xpdfVersion);
    fprintf(stderr, "%s\n\n", xpdfCopyright);
    if (!printVersion) {
      printUsage("pdftohtml", "<PDF-file> [<html-file> <xml-file>]", argDesc);
    }
    exit(1);
  }
  fileName = new GString(argv[1]);

  // init error file
  //errorInit();

  // read config file
  GString *paramFile = new GString("/xpdfrc");
  if (*langConfigDir != '\0') {  // then it'd better have xpdfrc!
    paramFile->insert(0, langConfigDir);
// on windows we'll assume we have read access to the file
#ifndef WIN32
    if (access(paramFile->getCString(), R_OK) != 0) {
      fprintf(stderr,
              "pdftohtml: cannot read config file: %s: %s\n",
              paramFile->getCString(), strerror(errno));
      exit(2);
    }
#endif
  } else {
    // do nothing -- GlobalParams will look for xpdfrc in its path
    // and silently ignore it if not found
  }
  globalParams = new GlobalParams(paramFile->getCString(), errQuiet);

  if (errQuiet) {
    printCommands = gFalse; // I'm not 100% what is the differecne between them
  }

  if (textEncName[0]) {
    globalParams->setTextEncoding(textEncName);
  }

  // open PDF file
  if (ownerPassword[0]) {
    ownerPW = new GString(ownerPassword);
  } else {
    ownerPW = NULL;
  }
  if (userPassword[0]) {
    userPW = new GString(userPassword);
  } else {
    userPW = NULL;
  }
  doc = new PDFDoc(fileName, ownerPW, userPW);
  if (userPW) {
    delete userPW;
  }
  if (ownerPW) {
    delete ownerPW;
  }
  if (!doc->isOk()) {
    fprintf(stderr, "pdftohtml: cannot load input file: %s\n",
            fileName->getCString());
    exit(3);
  }

  // check for copy permission
  if (!doc->okToCopy() || !doc->okToPrint() || !doc->okToChange()) {
    noArchive = gTrue;
  }

  // construct text file name
  if (argc == 3) {
    GString* tmp = new GString(argv[2]);
    p=tmp->getCString()+tmp->getLength()-5;
    if (!xml)
      if (!strcmp(p, ".html") || !strcmp(p, ".HTML"))
	htmlFileName = new GString(tmp->getCString(),
				   tmp->getLength() - 5);
      else htmlFileName =new GString(tmp);
    else   
      if (!strcmp(p, ".xml") || !strcmp(p, ".XML"))
	htmlFileName = new GString(tmp->getCString(),
				   tmp->getLength() - 5);
      else htmlFileName =new GString(tmp);
    
    delete tmp;
  } else {
    p = fileName->getCString() + fileName->getLength() - 4;
    if (!strcmp(p, ".pdf") || !strcmp(p, ".PDF"))
      htmlFileName = new GString(fileName->getCString(),
				 fileName->getLength() - 4);
    else
      htmlFileName = fileName->copy();
    //   htmlFileName->append(".html");
  }
  
   if (scale>3.0) scale=3.0;
   if (scale<0.5) scale=0.5;
   
   if (mode) {
     noframes=gFalse;
     stout=gFalse;
   } 

   if (stout) {
     noframes=gTrue;
     mode=gFalse;
   }

   if (xml)
     { 
       mode = gTrue;
       noframes = gTrue;
     }

  // get page range
  if (firstPage < 1)
    firstPage = 1;
  if (lastPage < 1 || lastPage > doc->getNumPages())
    lastPage = doc->getNumPages();

  if (maxNumPages >= 0 && lastPage > maxNumPages)  {
    lastPage = maxNumPages;
  }

  doc->getDocInfo(&info);
  if (info.isDict()) {
    docTitle = getInfoString(info.getDict(), "Title");
    if ( !docTitle ) docTitle = new GString(htmlFileName);
    glMetaVars = collectMetaData(info.getDict());
  }
  info.free();

  // write text file
  htmlOut = new HtmlOutputDev(htmlFileName->getCString(), docTitle,
                              glMetaVars, rawOrder, printHR);
  glMetaVars = NULL;    // ownership already transfered to HtmlOutputDev
  delete docTitle;

  if (htmlOut->isOk())  
    doc->displayPages(htmlOut, firstPage, lastPage, 72*scale, 72*scale, 0, gTrue);
  
// we won't support complex output for the windows version (we don't need it)
#ifndef WIN32
  if( mode && !xml ) {
    int h=xoutRound(htmlOut->getPageHeight()/scale);
    int w=xoutRound(htmlOut->getPageWidth()/scale);

    psFileName = new GString(htmlFileName->getCString());
    psFileName->append(".ps");

    globalParams->setPSPaperWidth(w);
    globalParams->setPSPaperHeight(h);
    psOut = new PSOutputDev(psFileName->getCString(), doc->getXRef(),
			    doc->getCatalog(), firstPage, lastPage, psModePS);
    doc->displayPages(psOut, firstPage, lastPage, 72.0, 72.0, 0, gFalse);
    delete psOut;

    /*sprintf(buf, "%s -sDEVICE=png16m -dBATCH -dNOPROMPT -dNOPAUSE -r72 -sOutputFile=%s%%03d.png -g%dx%d -q %s", GHOSTSCRIPT, htmlFileName->getCString(), w, h,
      psFileName->getCString());*/

    GString *gsCmd = new GString(GHOSTSCRIPT);
    GString *tw, *th;
    gsCmd->append(" -sDEVICE=png16m -dBATCH -dNOPROMPT -dNOPAUSE -r72 -sOutputFile=");
    gsCmd->append("\"");
    gsCmd->append(htmlFileName);
    gsCmd->append("%03d.png\" -g");
    tw = GString::fromInt(w);
    gsCmd->append(tw);
    gsCmd->append("x");
    th = GString::fromInt(h);
    gsCmd->append(th);
    gsCmd->append(" -q \"");
    gsCmd->append(psFileName);
    gsCmd->append("\"");
    //printf("running: %s\n", gsCmd->getCString());
    if( !executeCommand(gsCmd->getCString()) && !errQuiet) {
      error(-1, "Failed to launch Ghostscript!\n");
    }
    delete tw;
    delete th;
    delete gsCmd;
    delete psFileName;
  }
#endif // WIN32
  
  delete htmlOut;

  // clean up
 err2:
 err1:
  if(doc) delete doc;
  if(globalParams) delete globalParams;

  if(htmlFileName) delete htmlFileName;
  HtmlFont::clear();
  
  // check for memory leaks
  Object::memCheck(stderr);
  gMemReport(stderr);

  return 0;

#ifdef WIN32
  } __except (EXCEPTION_EXECUTE_HANDLER) {
#ifdef DEBUG
    ::OutputDebugString ("Exception in pdftohtml. Problems converting file:\n");
    ::OutputDebugString (argv[1]);
#endif      
    return 1; // 1 indicates that we had an error
  }
#endif

}

static GString* getInfoString(Dict *infoDict, char *key) {
  Object obj;
  GString *s1 = NULL;

  if (infoDict->lookup(key, &obj)->isString()) {
    s1 = new GString(obj.getString());
  }
  obj.free();
  return s1;
}
