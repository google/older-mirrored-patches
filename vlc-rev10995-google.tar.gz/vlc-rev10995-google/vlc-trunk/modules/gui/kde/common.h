/***************************************************************************
                          common.h  -  description
                             -------------------
    begin                : Mon Apr 9 2001
    copyright            : (C) 2001 by andres
    email                : dae@chez.com
 ***************************************************************************/

#ifndef _INTF_PLUGIN_H_
#define _INTF_PLUGIN_H_

#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>

#include <vlc/vlc.h>
#include <vlc/intf.h>

#endif /* _INTF_PLUGIN_H_ */
