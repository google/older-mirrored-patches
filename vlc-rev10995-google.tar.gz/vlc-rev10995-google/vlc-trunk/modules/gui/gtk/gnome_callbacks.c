/*****************************************************************************
 * This file is not used: everything is in gtk_callbacks.c
 *****************************************************************************/

void
GtkDiscOpenCDDA                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{

}

