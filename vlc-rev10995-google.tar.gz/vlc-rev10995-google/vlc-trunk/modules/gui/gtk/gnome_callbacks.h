/*****************************************************************************
 * This file is not needed: everything is in gtk_callbacks.h
 *****************************************************************************/
#include "gtk_callbacks.h"

void
GtkDiscOpenCDDA                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
